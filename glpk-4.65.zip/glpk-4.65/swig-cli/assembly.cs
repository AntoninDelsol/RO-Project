using System;
using System.Reflection;

// Assembly version
[assembly:AssemblyVersionAttribute(
    "1.10.0.0")]
[assembly:AssemblyCopyrightAttribute(
    "Heinrich Schuchardt <xypron.glpk@gmx.de>, GPLv3")]
[assembly:AssemblyProductAttribute(
    "GLPK for C#/CIL")]

// Mark assembly as compliant
[assembly:CLSCompliant(true)]
